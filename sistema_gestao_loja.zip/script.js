// Código JavaScript completo vai aqui (copiado da sua implementação anterior)
// Use os mesmos IDs e estrutura para funcionar corretamente
